"""
IPL Data Mining app components
"""
