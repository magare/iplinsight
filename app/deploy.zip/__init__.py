"""
IPL Data Mining app package
"""
