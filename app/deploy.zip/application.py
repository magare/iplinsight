"""
Entry point for AWS Elastic Beanstalk.
"""
import os
import sys
from app import main

if __name__ == "__main__":
    main()
