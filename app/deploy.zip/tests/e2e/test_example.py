"""
Example test case for the Streamlit app testing framework.

This script demonstrates how to use the testing framework to test a specific feature
of the Streamlit app.
"""

import sys
import time
from pathlib import Path

# Add the parent directory to the path so we can import the app modules
sys.path.insert(0, str(Path(__file__).parents[3]))

from selenium.webdriver.common.by import By
from app.tests.e2e.app_launcher import StreamlitAppLauncher
from app.tests.e2e.webdriver_manager import WebDriverManager
from app.tests.e2e.element_detector import ElementDetector
from app.tests.e2e.error_detector import ErrorDetector


def test_team_analysis():
    """Test the Team Analysis feature of the Streamlit app."""
    # Launch the Streamlit app
    with StreamlitAppLauncher() as app:
        # Start the WebDriver
        with WebDriverManager(headless=False) as webdriver:
            # Navigate to the app
            webdriver.driver.get(app.get_url())
            webdriver.wait_for_page_load()
            
            # Wait for Streamlit to load
            time.sleep(5)
            
            # Initialize element detector and error detector
            element_detector = ElementDetector(webdriver.driver)
            error_detector = ErrorDetector(webdriver.driver)
            
            # Take a screenshot of the initial page
            webdriver.take_screenshot("initial_page")
            
            # Find the sidebar navigation elements
            sidebar = webdriver.driver.find_element(By.CSS_SELECTOR, "[data-testid='stSidebar']")
            nav_elements = sidebar.find_elements(By.CSS_SELECTOR, "input[type='radio']")
            
            # Find and click the "Team Analysis" navigation element
            team_analysis_nav = None
            for nav_element in nav_elements:
                if nav_element.get_attribute("value") == "Team Analysis":
                    team_analysis_nav = nav_element
                    break
            
            if team_analysis_nav:
                print("Clicking on Team Analysis navigation")
                webdriver.driver.execute_script("arguments[0].scrollIntoView(true);", team_analysis_nav)
                team_analysis_nav.click()
                
                # Wait for the page to load
                time.sleep(2)
                
                # Take a screenshot after clicking
                webdriver.take_screenshot("team_analysis_page")
                
                # Check for errors
                errors = error_detector.check_for_errors()
                if errors['status'] != 'pass':
                    print("Errors found:", errors)
                else:
                    print("No errors found")
                
                # Find all interactive elements on the page
                elements = element_detector.find_all_interactive_elements()
                
                # Print the number of elements found
                for element_type, element_list in elements.items():
                    print(f"Found {len(element_list)} {element_type}")
                
                # Interact with the first dropdown if available
                if elements['selects'] and len(elements['selects']) > 0:
                    print("Interacting with the first dropdown")
                    element_detector.interact_with_element(elements['selects'][0], 'selects')
                    
                    # Wait for any changes to take effect
                    time.sleep(1)
                    
                    # Take a screenshot after interacting
                    webdriver.take_screenshot("team_analysis_dropdown")
                    
                    # Check for errors
                    errors = error_detector.check_for_errors()
                    if errors['status'] != 'pass':
                        print("Errors found after dropdown interaction:", errors)
                    else:
                        print("No errors found after dropdown interaction")
                
                print("Team Analysis test completed successfully")
            else:
                print("Team Analysis navigation element not found")


if __name__ == "__main__":
    test_team_analysis() 