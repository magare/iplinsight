import os
import json
import time
import datetime
from pathlib import Path
from collections import defaultdict


class PathEncoder(json.JSONEncoder):
    """Custom JSON encoder that handles Path objects."""
    def default(self, obj):
        if isinstance(obj, Path):
            return str(obj)
        return super().default(obj)


class TestReporter:
    """
    Generates reports of test results.
    """
    def __init__(self, report_dir=None):
        """
        Initialize the test reporter.
        
        Args:
            report_dir: Directory to save reports
        """
        self.report_dir = report_dir or Path(__file__).parents[1] / "reports"
        self.test_results = []
        self.start_time = None
        self.end_time = None
        
        # Create report directory if it doesn't exist
        os.makedirs(self.report_dir, exist_ok=True)
    
    def start_test_session(self):
        """Start a new test session."""
        self.start_time = time.time()
        self.test_results = []
    
    def end_test_session(self):
        """End the current test session."""
        self.end_time = time.time()
    
    def add_test_result(self, test_name, path, status, errors=None, screenshots=None, duration=None):
        """
        Add a test result.
        
        Args:
            test_name: Name of the test
            path: Path in the app that was tested
            status: Test status (pass, fail, warn)
            errors: Dictionary of errors
            screenshots: List of screenshot paths
            duration: Test duration in seconds
        """
        # Convert Path objects to strings for JSON serialization
        if screenshots:
            screenshots = [str(s) for s in screenshots]
            
        result = {
            'test_name': test_name,
            'path': path,
            'status': status,
            'errors': errors or {},
            'screenshots': screenshots or [],
            'duration': duration,
            'timestamp': datetime.datetime.now().isoformat()
        }
        
        self.test_results.append(result)
    
    def generate_json_report(self):
        """
        Generate a JSON report of test results.
        
        Returns:
            Path to the JSON report file
        """
        if not self.test_results:
            return None
        
        # Create a report object
        report = {
            'summary': self._generate_summary(),
            'results': self.test_results
        }
        
        # Save the report to a file
        timestamp = time.strftime("%Y%m%d-%H%M%S")
        filename = f"test_report_{timestamp}.json"
        filepath = self.report_dir / filename
        
        with open(filepath, 'w') as f:
            json.dump(report, f, indent=2, cls=PathEncoder)
        
        print(f"JSON report saved to {filepath}")
        
        return filepath
    
    def generate_html_report(self):
        """
        Generate an HTML report of test results.
        
        Returns:
            Path to the HTML report file
        """
        if not self.test_results:
            return None
        
        # Generate summary
        summary = self._generate_summary()
        
        # Create HTML content
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Streamlit App Test Report</title>
            <style>
                body {{
                    font-family: Arial, sans-serif;
                    line-height: 1.6;
                    margin: 0;
                    padding: 20px;
                    color: #333;
                }}
                h1, h2, h3 {{
                    color: #2c3e50;
                }}
                .summary {{
                    background-color: #f8f9fa;
                    border-radius: 5px;
                    padding: 15px;
                    margin-bottom: 20px;
                }}
                .summary-item {{
                    margin-bottom: 10px;
                }}
                .test-result {{
                    border: 1px solid #ddd;
                    border-radius: 5px;
                    padding: 15px;
                    margin-bottom: 15px;
                }}
                .pass {{
                    border-left: 5px solid #28a745;
                }}
                .fail {{
                    border-left: 5px solid #dc3545;
                }}
                .warn {{
                    border-left: 5px solid #ffc107;
                }}
                .error-details {{
                    background-color: #f8f9fa;
                    border-radius: 5px;
                    padding: 10px;
                    margin-top: 10px;
                    white-space: pre-wrap;
                    font-family: monospace;
                }}
                .screenshot {{
                    max-width: 300px;
                    margin-top: 10px;
                    border: 1px solid #ddd;
                    border-radius: 3px;
                }}
                .timestamp {{
                    color: #6c757d;
                    font-size: 0.9em;
                }}
            </style>
        </head>
        <body>
            <h1>Streamlit App Test Report</h1>
            
            <div class="summary">
                <h2>Summary</h2>
                <div class="summary-item"><strong>Total Tests:</strong> {summary['total_tests']}</div>
                <div class="summary-item"><strong>Passed:</strong> {summary['passed']} ({summary['pass_percentage']}%)</div>
                <div class="summary-item"><strong>Failed:</strong> {summary['failed']}</div>
                <div class="summary-item"><strong>Warnings:</strong> {summary['warnings']}</div>
                <div class="summary-item"><strong>Total Duration:</strong> {summary['total_duration']} seconds</div>
                <div class="summary-item"><strong>Start Time:</strong> {summary['start_time']}</div>
                <div class="summary-item"><strong>End Time:</strong> {summary['end_time']}</div>
            </div>
            
            <h2>Test Results</h2>
        """
        
        # Add each test result
        for result in self.test_results:
            status_class = result['status']
            
            html_content += f"""
            <div class="test-result {status_class}">
                <h3>{result['test_name']}</h3>
                <div><strong>Path:</strong> {result['path']}</div>
                <div><strong>Status:</strong> {result['status'].upper()}</div>
                <div><strong>Duration:</strong> {result['duration']} seconds</div>
                <div class="timestamp">{result['timestamp']}</div>
            """
            
            # Add error details if any
            if result['errors']:
                html_content += "<h4>Errors:</h4>"
                
                if result['errors'].get('error_messages'):
                    html_content += "<div><strong>Error Messages:</strong></div>"
                    html_content += "<div class='error-details'>"
                    for msg in result['errors']['error_messages']:
                        html_content += f"{msg}<br>"
                    html_content += "</div>"
                
                if result['errors'].get('console_errors'):
                    html_content += "<div><strong>Console Errors:</strong></div>"
                    html_content += "<div class='error-details'>"
                    for msg in result['errors']['console_errors']:
                        html_content += f"{msg}<br>"
                    html_content += "</div>"
                
                if result['errors'].get('visual_anomalies'):
                    html_content += "<div><strong>Visual Anomalies:</strong></div>"
                    html_content += "<div class='error-details'>"
                    for msg in result['errors']['visual_anomalies']:
                        html_content += f"{msg}<br>"
                    html_content += "</div>"
            
            # Add screenshots if any
            if result['screenshots']:
                html_content += "<h4>Screenshots:</h4>"
                for screenshot in result['screenshots']:
                    # Convert to relative path for HTML
                    rel_path = os.path.relpath(screenshot, self.report_dir)
                    html_content += f"<div><img class='screenshot' src='{rel_path}' alt='Screenshot'></div>"
            
            html_content += "</div>"
        
        # Close HTML
        html_content += """
        </body>
        </html>
        """
        
        # Save the report to a file
        timestamp = time.strftime("%Y%m%d-%H%M%S")
        filename = f"test_report_{timestamp}.html"
        filepath = self.report_dir / filename
        
        with open(filepath, 'w') as f:
            f.write(html_content)
        
        print(f"HTML report saved to {filepath}")
        
        return filepath
    
    def _generate_summary(self):
        """
        Generate a summary of test results.
        
        Returns:
            Dictionary with summary information
        """
        total_tests = len(self.test_results)
        passed = sum(1 for r in self.test_results if r['status'] == 'pass')
        failed = sum(1 for r in self.test_results if r['status'] == 'fail')
        warnings = sum(1 for r in self.test_results if r['status'] == 'warn')
        
        # Calculate pass percentage
        pass_percentage = round((passed / total_tests) * 100) if total_tests > 0 else 0
        
        # Calculate total duration
        total_duration = round(sum(r['duration'] for r in self.test_results if r['duration'] is not None), 2)
        
        # Format timestamps
        start_time = datetime.datetime.fromtimestamp(self.start_time).isoformat() if self.start_time else None
        end_time = datetime.datetime.fromtimestamp(self.end_time).isoformat() if self.end_time else None
        
        return {
            'total_tests': total_tests,
            'passed': passed,
            'failed': failed,
            'warnings': warnings,
            'pass_percentage': pass_percentage,
            'total_duration': total_duration,
            'start_time': start_time,
            'end_time': end_time
        }
    
    def print_summary(self):
        """Print a summary of test results to the console."""
        if not self.test_results:
            print("No test results to summarize")
            return
        
        summary = self._generate_summary()
        
        print("\n" + "=" * 50)
        print("TEST SUMMARY")
        print("=" * 50)
        print(f"Total Tests: {summary['total_tests']}")
        print(f"Passed: {summary['passed']} ({summary['pass_percentage']}%)")
        print(f"Failed: {summary['failed']}")
        print(f"Warnings: {summary['warnings']}")
        print(f"Total Duration: {summary['total_duration']} seconds")
        print("=" * 50)
        
        # Print failed tests
        if summary['failed'] > 0:
            print("\nFAILED TESTS:")
            for result in self.test_results:
                if result['status'] == 'fail':
                    print(f"- {result['test_name']} ({result['path']})")
        
        print("\n") 