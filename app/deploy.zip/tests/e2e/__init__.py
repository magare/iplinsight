"""
End-to-End Testing Framework for Streamlit Apps

This package provides a framework for end-to-end testing of Streamlit applications.
It launches the actual Streamlit app in a separate process and uses Selenium for
browser automation to interact with the UI.
"""

__version__ = "1.0.0" 