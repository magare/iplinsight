import re
import time
from pathlib import Path
from PIL import Image, ImageChops
from selenium.webdriver.common.by import By


class ErrorDetector:
    """
    Detects errors, exceptions, and visual anomalies in a Streamlit app.
    """
    def __init__(self, driver, screenshot_dir=None):
        """
        Initialize the error detector.
        
        Args:
            driver: Selenium WebDriver instance
            screenshot_dir: Directory to save screenshots
        """
        self.driver = driver
        self.screenshot_dir = screenshot_dir or Path(__file__).parents[1] / "screenshots"
        self.baseline_screenshots = {}
    
    def check_for_errors(self):
        """
        Check for errors in the current page.
        
        Returns:
            Dictionary with error information
        """
        errors = {
            'exception_found': False,
            'error_messages': [],
            'console_errors': [],
            'visual_anomalies': [],
            'status': 'pass'
        }
        
        # Check for Python exceptions
        exception = self._check_for_exceptions()
        if exception:
            errors['exception_found'] = True
            errors['error_messages'].append(exception)
            errors['status'] = 'fail'
        
        # Check for error messages in the UI
        ui_errors = self._check_for_ui_errors()
        if ui_errors:
            errors['error_messages'].extend(ui_errors)
            errors['status'] = 'fail'
        
        # Check console logs for errors
        console_errors = self._check_console_logs()
        if console_errors:
            errors['console_errors'] = console_errors
            # Only fail if there are actual errors, not warnings
            if any('ERROR' in err or 'SEVERE' in err for err in console_errors):
                errors['status'] = 'fail'
        
        # Check for visual anomalies
        visual_anomalies = self._check_for_visual_anomalies()
        if visual_anomalies:
            errors['visual_anomalies'] = visual_anomalies
            errors['status'] = 'warn'  # Visual anomalies are warnings, not failures
        
        return errors
    
    def _check_for_exceptions(self):
        """
        Check for Python exceptions in the page.
        
        Returns:
            Exception message if found, None otherwise
        """
        try:
            # Look for the Streamlit exception container
            exception_elements = self.driver.find_elements(
                By.CSS_SELECTOR, 
                ".stException, .streamlit-container.element-container .stAlert"
            )
            
            if exception_elements:
                for element in exception_elements:
                    text = element.text
                    if text and ('Error' in text or 'Exception' in text or 'Traceback' in text):
                        return text
            
            return None
        
        except Exception as e:
            print(f"Error checking for exceptions: {e}")
            return None
    
    def _check_for_ui_errors(self):
        """
        Check for error messages in the UI.
        
        Returns:
            List of error messages
        """
        try:
            # Look for elements that might contain error messages
            error_elements = self.driver.find_elements(
                By.CSS_SELECTOR,
                ".stAlert, .stException, .stError, [data-testid='stCaptionContainer'] code"
            )
            
            error_messages = []
            for element in error_elements:
                text = element.text
                if text and ('error' in text.lower() or 'exception' in text.lower() or 'failed' in text.lower()):
                    error_messages.append(text)
            
            return error_messages
        
        except Exception as e:
            print(f"Error checking for UI errors: {e}")
            return []
    
    def _check_console_logs(self):
        """
        Check browser console logs for errors.
        
        Returns:
            List of error messages
        """
        try:
            logs = self.driver.get_log('browser')
            
            # Filter for error and warning messages
            error_logs = []
            for log in logs:
                level = log.get('level', '').upper()
                message = log.get('message', '')
                
                # Only include errors and severe warnings
                if level in ('ERROR', 'SEVERE') or 'error' in message.lower() or 'exception' in message.lower():
                    # Clean up the message
                    message = re.sub(r'\s+', ' ', message).strip()
                    error_logs.append(f"[{level}] {message}")
            
            return error_logs
        
        except Exception as e:
            print(f"Error checking console logs: {e}")
            return []
    
    def take_baseline_screenshot(self, name):
        """
        Take a baseline screenshot for later comparison.
        
        Args:
            name: Name of the screenshot
        
        Returns:
            Path to the screenshot file
        """
        timestamp = time.strftime("%Y%m%d-%H%M%S")
        filename = f"{name}_baseline_{timestamp}.png"
        filepath = self.screenshot_dir / filename
        
        self.driver.save_screenshot(str(filepath))
        self.baseline_screenshots[name] = filepath
        
        return filepath
    
    def _check_for_visual_anomalies(self):
        """
        Check for visual anomalies by comparing with baseline screenshots.
        
        Returns:
            List of anomalies
        """
        # This is a simplified implementation
        # In a real-world scenario, you would use more sophisticated image comparison
        anomalies = []
        
        # Check if there are any completely blank areas where content should be
        try:
            # Take a screenshot
            screenshot_path = self.screenshot_dir / f"current_check_{time.strftime('%Y%m%d-%H%M%S')}.png"
            self.driver.save_screenshot(str(screenshot_path))
            
            # Load the image
            img = Image.open(screenshot_path)
            
            # Check if the image is mostly white or blank
            # This is a very simple check - in reality you'd want something more sophisticated
            extrema = img.convert("L").getextrema()
            if extrema[0] > 240 and extrema[1] < 250:  # If the image is mostly white
                anomalies.append("Page appears to be blank or mostly white")
            
            # Compare with baseline if available
            for name, baseline_path in self.baseline_screenshots.items():
                if baseline_path.exists():
                    baseline_img = Image.open(baseline_path)
                    
                    # Ensure both images are the same size
                    if baseline_img.size == img.size:
                        # Calculate difference
                        diff = ImageChops.difference(baseline_img, img)
                        
                        # If the images are significantly different
                        if diff.getbbox() is not None:
                            diff_extrema = diff.convert("L").getextrema()
                            if diff_extrema[1] > 50:  # If the maximum difference is significant
                                diff_path = self.screenshot_dir / f"{name}_diff_{time.strftime('%Y%m%d-%H%M%S')}.png"
                                diff.save(diff_path)
                                anomalies.append(f"Visual difference detected compared to baseline '{name}'")
            
            # Clean up the temporary screenshot
            screenshot_path.unlink(missing_ok=True)
            
        except Exception as e:
            print(f"Error checking for visual anomalies: {e}")
        
        return anomalies 