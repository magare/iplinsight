import os
import subprocess
import time
import signal
import psutil
import socket
import requests
from pathlib import Path

class StreamlitAppLauncher:
    """
    Launches a Streamlit app in a separate process for testing.
    """
    def __init__(self, app_path=None, port=8501, timeout=30):
        """
        Initialize the launcher.
        
        Args:
            app_path: Path to the Streamlit app file
            port: Port to run the Streamlit app on
            timeout: Timeout in seconds to wait for the app to start
        """
        self.app_path = app_path or Path(__file__).parents[2] / "app.py"
        self.port = self._find_free_port() if port is None else port
        self.timeout = timeout
        self.process = None
        
    def _find_free_port(self):
        """Find a free port to run the Streamlit app on."""
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(('', 0))
            return s.getsockname()[1]
        
    def start(self):
        """Start the Streamlit app in a separate process."""
        # Kill any existing Streamlit processes on the same port
        self._kill_existing_streamlit_processes()
        
        # Start the Streamlit app
        cmd = [
            "streamlit", "run", 
            str(self.app_path), 
            "--server.port", str(self.port),
            "--server.headless", "true",
            "--server.enableCORS", "false",
            "--server.enableXsrfProtection", "false",
            "--server.enableWebsocketCompression", "false",
            "--browser.gatherUsageStats", "false"
        ]
        
        # Use subprocess.Popen to start the process
        self.process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            preexec_fn=os.setpgrp if os.name != 'nt' else None
        )
        
        # Wait for the app to start
        start_time = time.time()
        while time.time() - start_time < self.timeout:
            try:
                response = requests.get(f"http://localhost:{self.port}/healthz")
                if response.status_code == 200:
                    print(f"Streamlit app started on port {self.port}")
                    return True
            except requests.exceptions.ConnectionError:
                pass
            
            # Check if the process is still running
            if self.process.poll() is not None:
                stdout, stderr = self.process.communicate()
                print(f"Streamlit process exited with code {self.process.returncode}")
                print(f"STDOUT: {stdout}")
                print(f"STDERR: {stderr}")
                return False
            
            time.sleep(0.5)
            
        print(f"Timed out waiting for Streamlit app to start on port {self.port}")
        self.stop()
        return False
    
    def _kill_existing_streamlit_processes(self):
        """Kill any existing Streamlit processes on the same port."""
        for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
            try:
                cmdline = proc.info['cmdline']
                if cmdline and 'streamlit' in cmdline[0] and 'run' in cmdline and f"--server.port {self.port}" in ' '.join(cmdline):
                    print(f"Killing existing Streamlit process: {proc.info['pid']}")
                    if os.name == 'nt':
                        subprocess.call(['taskkill', '/F', '/T', '/PID', str(proc.info['pid'])])
                    else:
                        os.kill(proc.info['pid'], signal.SIGTERM)
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                pass
    
    def stop(self):
        """Stop the Streamlit app process."""
        if self.process:
            if os.name == 'nt':
                subprocess.call(['taskkill', '/F', '/T', '/PID', str(self.process.pid)])
            else:
                try:
                    pgid = os.getpgid(self.process.pid)
                    os.killpg(pgid, signal.SIGTERM)
                except (ProcessLookupError, PermissionError):
                    # Process might have already exited
                    pass
            
            self.process = None
            print("Streamlit app stopped")
    
    def get_url(self):
        """Get the URL of the Streamlit app."""
        return f"http://localhost:{self.port}"
    
    def __enter__(self):
        """Context manager entry point."""
        self.start()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit point."""
        self.stop()


if __name__ == "__main__":
    # Test the launcher
    launcher = StreamlitAppLauncher()
    try:
        if launcher.start():
            print(f"Streamlit app running at {launcher.get_url()}")
            time.sleep(5)  # Keep running for 5 seconds
    finally:
        launcher.stop() 