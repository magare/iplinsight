import time
import traceback
from pathlib import Path
from selenium.webdriver.common.by import By
from selenium.common.exceptions import WebDriverException

from app.tests.e2e.app_launcher import StreamlitAppLauncher
from app.tests.e2e.webdriver_manager import WebDriverManager
from app.tests.e2e.element_detector import ElementDetector
from app.tests.e2e.error_detector import ErrorDetector
from app.tests.e2e.test_reporter import TestReporter


class StreamlitTestRunner:
    """
    Main test runner for Streamlit app testing.
    """
    def __init__(self, app_path=None, port=None, headless=True, screenshot_dir=None, report_dir=None, max_elements=10, wait_time=5):
        """
        Initialize the test runner.
        
        Args:
            app_path: Path to the Streamlit app file
            port: Port to run the Streamlit app on
            headless: Whether to run the browser in headless mode
            screenshot_dir: Directory to save screenshots
            report_dir: Directory to save reports
            max_elements: Maximum number of elements to test
            wait_time: Wait time in seconds for elements to appear
        """
        self.app_path = app_path
        self.port = port
        self.headless = headless
        self.screenshot_dir = screenshot_dir or Path(__file__).parents[1] / "screenshots"
        self.report_dir = report_dir or Path(__file__).parents[1] / "reports"
        self.max_elements = max_elements
        self.wait_time = wait_time
        
        # Initialize components
        self.app_launcher = None
        self.webdriver = None
        self.element_detector = None
        self.error_detector = None
        self.reporter = TestReporter(report_dir=self.report_dir)
        
        # Test state
        self.visited_paths = set()
        self.current_path = None
    
    def setup(self):
        """Set up the test environment."""
        # Start the Streamlit app
        self.app_launcher = StreamlitAppLauncher(app_path=self.app_path, port=self.port, timeout=self.wait_time * 2)
        if not self.app_launcher.start():
            raise RuntimeError("Failed to start Streamlit app")
        
        # Start the WebDriver
        self.webdriver = WebDriverManager(headless=self.headless, screenshot_dir=self.screenshot_dir)
        self.webdriver.start()
        
        # Initialize element detector and error detector
        self.element_detector = ElementDetector(self.webdriver.driver, wait_time=self.wait_time)
        self.error_detector = ErrorDetector(self.webdriver.driver, screenshot_dir=self.screenshot_dir)
        
        # Start the test session
        self.reporter.start_test_session()
    
    def teardown(self):
        """Tear down the test environment."""
        # End the test session
        self.reporter.end_test_session()
        
        # Stop the WebDriver
        if self.webdriver:
            self.webdriver.stop()
        
        # Stop the Streamlit app
        if self.app_launcher:
            self.app_launcher.stop()
    
    def run_tests(self):
        """
        Run the tests.
        
        Returns:
            Path to the HTML report file
        """
        try:
            self.setup()
            
            # Navigate to the app
            self._navigate_to_app()
            
            # Traverse the app
            self._traverse_app()
            
            # Generate reports
            self.reporter.print_summary()
            json_report = self.reporter.generate_json_report()
            html_report = self.reporter.generate_html_report()
            
            return html_report
        
        except Exception as e:
            print(f"Error running tests: {e}")
            traceback.print_exc()
            return None
        
        finally:
            self.teardown()
    
    def _navigate_to_app(self):
        """Navigate to the Streamlit app."""
        url = self.app_launcher.get_url()
        print(f"Navigating to {url}")
        
        self.webdriver.driver.get(url)
        self.webdriver.wait_for_page_load()
        
        # Wait for Streamlit to load
        time.sleep(self.wait_time)
        
        # Take a screenshot of the initial page
        self.webdriver.take_screenshot("initial_page")
        
        # Set the current path
        self.current_path = "/"
    
    def _traverse_app(self):
        """Traverse the app by interacting with all elements."""
        # Start with the main navigation in the sidebar
        self._test_sidebar_navigation()
        
        # Process any remaining paths that were discovered but not visited
        while len(self.visited_paths) < self.max_elements:  # Limit to prevent infinite loops
            # Find all interactive elements on the current page
            elements = self.element_detector.find_all_interactive_elements()
            
            # If no elements found, break
            if sum(len(elements[key]) for key in elements) == 0:
                break
            
            # Interact with each element
            for element_type, element_list in elements.items():
                for i, element in enumerate(element_list):
                    # Skip if we've already visited too many paths
                    if len(self.visited_paths) >= self.max_elements:
                        break
                    
                    # Generate a unique path for this element
                    element_path = f"{self.current_path}/{element_type}_{i}"
                    
                    # Skip if we've already visited this path
                    if element_path in self.visited_paths:
                        continue
                    
                    # Mark this path as visited
                    self.visited_paths.add(element_path)
                    
                    # Test this element
                    self._test_element(element, element_type, element_path)
    
    def _test_sidebar_navigation(self):
        """Test the sidebar navigation."""
        try:
            # Find the sidebar navigation elements
            sidebar = self.webdriver.driver.find_element(By.CSS_SELECTOR, "[data-testid='stSidebar']")
            
            # In Streamlit, the radio buttons in the sidebar are actually labels that wrap the radio inputs
            # We need to find the labels and click them instead of the inputs
            nav_labels = sidebar.find_elements(By.CSS_SELECTOR, "div[data-testid='stRadio'] label")
            
            # If no labels found, try to find the radio buttons directly
            if not nav_labels:
                # Try to find the radio container and then the labels inside it
                radio_container = sidebar.find_element(By.CSS_SELECTOR, "div[data-testid='stRadio']")
                if radio_container:
                    nav_labels = radio_container.find_elements(By.CSS_SELECTOR, "label")
            
            # If still no labels found, try to find any clickable elements in the sidebar
            if not nav_labels:
                nav_labels = sidebar.find_elements(By.CSS_SELECTOR, "div.row-widget button, div.row-widget a")
            
            # Test each navigation element
            for i, nav_element in enumerate(nav_labels):
                # Skip if we've already visited too many paths
                if len(self.visited_paths) >= self.max_elements:
                    break
                
                # Try to get the label text
                try:
                    label = nav_element.text.strip()
                    if not label:
                        label = f"Option {i+1}"
                except:
                    label = f"Option {i+1}"
                
                nav_path = f"/sidebar/{label}"
                
                # Skip if we've already visited this path
                if nav_path in self.visited_paths:
                    continue
                
                # Mark this path as visited
                self.visited_paths.add(nav_path)
                
                # Test this navigation element
                print(f"Testing sidebar navigation: {label}")
                
                # Take a screenshot before clicking
                screenshot_before = self.webdriver.take_screenshot(f"sidebar_nav_{label}_before")
                
                # Start timing
                start_time = time.time()
                
                # Click the navigation element
                try:
                    # Scroll to the element to make sure it's visible
                    self.webdriver.driver.execute_script("arguments[0].scrollIntoView(true);", nav_element)
                    
                    # Wait a moment for the scroll to complete
                    time.sleep(0.5)
                    
                    # Try to click the element using JavaScript
                    self.webdriver.driver.execute_script("arguments[0].click();", nav_element)
                    
                    # Wait for the page to load
                    time.sleep(2)
                    
                    # Take a screenshot after clicking
                    screenshot_after = self.webdriver.take_screenshot(f"sidebar_nav_{label}_after")
                    
                    # Check for errors
                    errors = self.error_detector.check_for_errors()
                    
                    # End timing
                    duration = time.time() - start_time
                    
                    # Add the test result
                    self.reporter.add_test_result(
                        test_name=f"Sidebar Navigation - {label}",
                        path=nav_path,
                        status=errors['status'],
                        errors=errors,
                        screenshots=[screenshot_before, screenshot_after],
                        duration=duration
                    )
                    
                    # Update the current path
                    self.current_path = nav_path
                    
                except WebDriverException as e:
                    print(f"Error clicking sidebar navigation {label}: {e}")
                    
                    # End timing
                    duration = time.time() - start_time
                    
                    # Add the test result
                    self.reporter.add_test_result(
                        test_name=f"Sidebar Navigation - {label}",
                        path=nav_path,
                        status="fail",
                        errors={
                            'exception_found': True,
                            'error_messages': [str(e)],
                            'console_errors': [],
                            'visual_anomalies': []
                        },
                        screenshots=[screenshot_before],
                        duration=duration
                    )
        
        except Exception as e:
            print(f"Error testing sidebar navigation: {e}")
    
    def _test_element(self, element, element_type, element_path):
        """
        Test an interactive element.
        
        Args:
            element: The element to test
            element_type: The type of element
            element_path: The path of the element
        """
        print(f"Testing {element_type} at {element_path}")
        
        # Take a screenshot before interacting
        screenshot_before = self.webdriver.take_screenshot(f"{element_type}_before")
        
        # Start timing
        start_time = time.time()
        
        try:
            # Interact with the element
            success = self.element_detector.interact_with_element(element, element_type)
            
            # Wait for any changes to take effect
            time.sleep(1)
            
            # Take a screenshot after interacting
            screenshot_after = self.webdriver.take_screenshot(f"{element_type}_after")
            
            # Check for errors
            errors = self.error_detector.check_for_errors()
            
            # End timing
            duration = time.time() - start_time
            
            # If interaction failed, mark as failed
            if not success:
                errors['status'] = 'fail'
                errors['error_messages'].append(f"Failed to interact with {element_type}")
            
            # Add the test result
            self.reporter.add_test_result(
                test_name=f"{element_type.capitalize()} Interaction",
                path=element_path,
                status=errors['status'],
                errors=errors,
                screenshots=[screenshot_before, screenshot_after],
                duration=duration
            )
            
            # Update the current path
            self.current_path = element_path
            
        except Exception as e:
            print(f"Error testing {element_type} at {element_path}: {e}")
            
            # End timing
            duration = time.time() - start_time
            
            # Add the test result
            self.reporter.add_test_result(
                test_name=f"{element_type.capitalize()} Interaction",
                path=element_path,
                status="fail",
                errors={
                    'exception_found': True,
                    'error_messages': [str(e)],
                    'console_errors': [],
                    'visual_anomalies': []
                },
                screenshots=[screenshot_before],
                duration=duration
            )


if __name__ == "__main__":
    # Run the tests
    runner = StreamlitTestRunner()
    report_path = runner.run_tests()
    
    if report_path:
        print(f"Test report generated at {report_path}")
    else:
        print("Failed to generate test report") 