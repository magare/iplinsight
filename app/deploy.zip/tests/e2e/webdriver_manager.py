import os
import time
from pathlib import Path
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, WebDriverException


class WebDriverManager:
    """
    Manages the Selenium WebDriver for browser automation.
    """
    def __init__(self, headless=True, screenshot_dir=None, window_size=(1920, 1080)):
        """
        Initialize the WebDriver manager.
        
        Args:
            headless: Whether to run the browser in headless mode
            screenshot_dir: Directory to save screenshots
            window_size: Window size (width, height)
        """
        self.headless = headless
        self.screenshot_dir = screenshot_dir or Path(__file__).parents[1] / "screenshots"
        self.window_size = window_size
        self.driver = None
        
        # Create screenshot directory if it doesn't exist
        os.makedirs(self.screenshot_dir, exist_ok=True)
    
    def start(self):
        """Start the WebDriver."""
        options = Options()
        if self.headless:
            options.add_argument("--headless")
        
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument(f"--window-size={self.window_size[0]},{self.window_size[1]}")
        options.add_argument("--disable-gpu")
        options.add_argument("--disable-extensions")
        options.add_argument("--disable-notifications")
        
        # Enable browser console logs
        options.add_argument("--enable-logging")
        options.add_argument("--v=1")
        
        # Set up the Chrome driver
        service = Service(ChromeDriverManager().install())
        self.driver = webdriver.Chrome(service=service, options=options)
        self.driver.set_window_size(self.window_size[0], self.window_size[1])
        
        return self.driver
    
    def stop(self):
        """Stop the WebDriver."""
        if self.driver:
            self.driver.quit()
            self.driver = None
    
    def take_screenshot(self, name):
        """
        Take a screenshot of the current page.
        
        Args:
            name: Name of the screenshot file (without extension)
        
        Returns:
            Path to the screenshot file
        """
        if not self.driver:
            raise ValueError("WebDriver not started")
        
        # Create a timestamped filename
        timestamp = time.strftime("%Y%m%d-%H%M%S")
        filename = f"{name}_{timestamp}.png"
        filepath = self.screenshot_dir / filename
        
        # Take the screenshot
        self.driver.save_screenshot(str(filepath))
        print(f"Screenshot saved to {filepath}")
        
        return filepath
    
    def get_console_logs(self):
        """
        Get browser console logs.
        
        Returns:
            List of console log entries
        """
        if not self.driver:
            raise ValueError("WebDriver not started")
        
        try:
            return self.driver.get_log('browser')
        except WebDriverException:
            # Some browsers don't support getting logs
            return []
    
    def wait_for_element(self, locator, timeout=10):
        """
        Wait for an element to be present.
        
        Args:
            locator: (By, value) tuple
            timeout: Timeout in seconds
        
        Returns:
            The element if found, None otherwise
        """
        if not self.driver:
            raise ValueError("WebDriver not started")
        
        try:
            return WebDriverWait(self.driver, timeout).until(
                EC.presence_of_element_located(locator)
            )
        except TimeoutException:
            return None
    
    def wait_for_page_load(self, timeout=30):
        """
        Wait for the page to load.
        
        Args:
            timeout: Timeout in seconds
        
        Returns:
            True if the page loaded, False otherwise
        """
        if not self.driver:
            raise ValueError("WebDriver not started")
        
        try:
            WebDriverWait(self.driver, timeout).until(
                lambda d: d.execute_script("return document.readyState") == "complete"
            )
            return True
        except TimeoutException:
            return False
    
    def __enter__(self):
        """Context manager entry point."""
        self.start()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit point."""
        self.stop() 