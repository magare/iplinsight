import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import TimeoutException, StaleElementReferenceException, NoSuchElementException, ElementClickInterceptedException


class ElementDetector:
    """
    Detects and interacts with UI elements in a Streamlit app.
    """
    def __init__(self, driver, wait_time=10):
        """
        Initialize the element detector.
        
        Args:
            driver: Selenium WebDriver instance
            wait_time: Default wait time for elements to appear
        """
        self.driver = driver
        self.wait_time = wait_time
    
    def find_all_interactive_elements(self):
        """
        Find all interactive elements in the current page.
        
        Returns:
            Dictionary of element types and their elements
        """
        # Wait for the Streamlit app to load
        self._wait_for_streamlit_load()
        
        # Find all interactive elements
        elements = {
            'buttons': self._find_buttons(),
            'radio_buttons': self._find_radio_buttons(),
            'checkboxes': self._find_checkboxes(),
            'selects': self._find_selects(),
            'multiselects': self._find_multiselects(),
            'sliders': self._find_sliders(),
            'number_inputs': self._find_number_inputs(),
            'text_inputs': self._find_text_inputs(),
            'date_inputs': self._find_date_inputs(),
            'tabs': self._find_tabs(),
            'expanders': self._find_expanders(),
            'links': self._find_links()
        }
        
        # Count total elements
        total_elements = sum(len(elements[key]) for key in elements)
        print(f"Found {total_elements} interactive elements")
        
        return elements
    
    def _wait_for_streamlit_load(self):
        """Wait for the Streamlit app to load."""
        try:
            # Wait for the main content to load
            WebDriverWait(self.driver, self.wait_time).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, "[data-testid='stAppViewContainer']"))
            )
            
            # Wait a bit more for all elements to render
            time.sleep(2)
            
            return True
        except TimeoutException:
            print("Timed out waiting for Streamlit app to load")
            return False
    
    def _find_buttons(self):
        """Find all buttons in the page."""
        try:
            # Find standard buttons that are visible and not hidden
            buttons = self.driver.find_elements(
                By.CSS_SELECTOR, 
                "button:not([aria-hidden='true']):not([style*='display: none']):not([style*='visibility: hidden'])"
            )
            
            # Find Streamlit buttons
            st_buttons = self.driver.find_elements(
                By.CSS_SELECTOR, 
                "[data-testid='stButton'] button:not([style*='display: none']):not([style*='visibility: hidden'])"
            )
            
            # Filter out buttons that are not visible or not clickable
            visible_buttons = []
            for button in buttons + st_buttons:
                try:
                    if button.is_displayed() and button.is_enabled():
                        visible_buttons.append(button)
                except StaleElementReferenceException:
                    continue
            
            return visible_buttons
        except Exception as e:
            print(f"Error finding buttons: {e}")
            return []
    
    def _find_radio_buttons(self):
        """Find all radio buttons in the page."""
        try:
            # Find radio button containers
            radio_containers = self.driver.find_elements(By.CSS_SELECTOR, "[data-testid='stRadio']")
            
            # Find individual radio buttons within containers
            radio_buttons = []
            for container in radio_containers:
                try:
                    # Try to find the labels first (which are more clickable)
                    labels = container.find_elements(By.CSS_SELECTOR, "label")
                    if labels:
                        radio_buttons.extend(labels)
                    else:
                        # Fall back to the inputs if no labels found
                        inputs = container.find_elements(By.CSS_SELECTOR, "input[type='radio']")
                        radio_buttons.extend(inputs)
                except StaleElementReferenceException:
                    continue
            
            return radio_buttons
        except Exception as e:
            print(f"Error finding radio buttons: {e}")
            return []
    
    def _find_checkboxes(self):
        """Find all checkboxes in the page."""
        try:
            # Find checkbox containers
            checkbox_containers = self.driver.find_elements(By.CSS_SELECTOR, "[data-testid='stCheckbox']")
            
            # Find individual checkboxes within containers
            checkboxes = []
            for container in checkbox_containers:
                try:
                    # Try to find the labels first (which are more clickable)
                    labels = container.find_elements(By.CSS_SELECTOR, "label")
                    if labels:
                        checkboxes.extend(labels)
                    else:
                        # Fall back to the inputs if no labels found
                        inputs = container.find_elements(By.CSS_SELECTOR, "input[type='checkbox']")
                        checkboxes.extend(inputs)
                except StaleElementReferenceException:
                    continue
            
            return checkboxes
        except Exception as e:
            print(f"Error finding checkboxes: {e}")
            return []
    
    def _find_selects(self):
        """Find all select dropdowns in the page."""
        try:
            return self.driver.find_elements(By.CSS_SELECTOR, "[data-testid='stSelectbox']")
        except Exception as e:
            print(f"Error finding selects: {e}")
            return []
    
    def _find_multiselects(self):
        """Find all multiselect dropdowns in the page."""
        try:
            return self.driver.find_elements(By.CSS_SELECTOR, "[data-testid='stMultiSelect']")
        except Exception as e:
            print(f"Error finding multiselects: {e}")
            return []
    
    def _find_sliders(self):
        """Find all sliders in the page."""
        try:
            return self.driver.find_elements(By.CSS_SELECTOR, "[data-testid='stSlider']")
        except Exception as e:
            print(f"Error finding sliders: {e}")
            return []
    
    def _find_number_inputs(self):
        """Find all number inputs in the page."""
        try:
            return self.driver.find_elements(By.CSS_SELECTOR, "[data-testid='stNumberInput']")
        except Exception as e:
            print(f"Error finding number inputs: {e}")
            return []
    
    def _find_text_inputs(self):
        """Find all text inputs in the page."""
        try:
            return self.driver.find_elements(By.CSS_SELECTOR, "[data-testid='stTextInput']")
        except Exception as e:
            print(f"Error finding text inputs: {e}")
            return []
    
    def _find_date_inputs(self):
        """Find all date inputs in the page."""
        try:
            return self.driver.find_elements(By.CSS_SELECTOR, "[data-testid='stDateInput']")
        except Exception as e:
            print(f"Error finding date inputs: {e}")
            return []
    
    def _find_tabs(self):
        """Find all tabs in the page."""
        try:
            return self.driver.find_elements(By.CSS_SELECTOR, "[data-testid='stTabs'] [role='tab']")
        except Exception as e:
            print(f"Error finding tabs: {e}")
            return []
    
    def _find_expanders(self):
        """Find all expanders in the page."""
        try:
            return self.driver.find_elements(By.CSS_SELECTOR, "[data-testid='stExpander']")
        except Exception as e:
            print(f"Error finding expanders: {e}")
            return []
    
    def _find_links(self):
        """Find all links in the page."""
        try:
            return self.driver.find_elements(By.CSS_SELECTOR, "a:not([aria-hidden='true'])")
        except Exception as e:
            print(f"Error finding links: {e}")
            return []
    
    def interact_with_element(self, element, element_type):
        """
        Interact with an element based on its type.
        
        Args:
            element: The element to interact with
            element_type: The type of element
        
        Returns:
            True if interaction was successful, False otherwise
        """
        try:
            # First, check if the element is still valid and visible
            try:
                if not element.is_enabled() or not element.is_displayed():
                    print(f"Element is not enabled or not displayed: {element_type}")
                    return False
            except StaleElementReferenceException:
                print(f"Element is stale: {element_type}")
                return False
            
            # Scroll to the element to make sure it's in view
            self.driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", element)
            
            # Wait a moment for the scroll to complete
            time.sleep(0.5)
            
            if element_type == 'buttons':
                # Try to click the button using JavaScript first
                try:
                    self.driver.execute_script("arguments[0].click();", element)
                    return True
                except Exception as e:
                    print(f"JavaScript click failed: {e}")
                    
                    # If JavaScript click fails, try regular click
                    try:
                        element.click()
                        return True
                    except ElementClickInterceptedException:
                        # If the element is intercepted, try to click the center of the element
                        try:
                            action = ActionChains(self.driver)
                            action.move_to_element(element).click().perform()
                            return True
                        except Exception as e2:
                            print(f"Action chains click failed: {e2}")
                            return False
            
            elif element_type == 'radio_buttons':
                # Try JavaScript click first
                try:
                    self.driver.execute_script("arguments[0].click();", element)
                    return True
                except Exception:
                    # If JavaScript click fails, try regular click
                    try:
                        element.click()
                        return True
                    except Exception:
                        return False
            
            elif element_type == 'checkboxes':
                # Try JavaScript click first
                try:
                    self.driver.execute_script("arguments[0].click();", element)
                    return True
                except Exception:
                    # If JavaScript click fails, try regular click
                    try:
                        element.click()
                        return True
                    except Exception:
                        return False
            
            elif element_type == 'selects':
                # Try to click the select to open the dropdown
                try:
                    self.driver.execute_script("arguments[0].click();", element)
                    
                    # Wait for the dropdown to open
                    time.sleep(1)
                    
                    # Find and click the first option
                    try:
                        options = self.driver.find_elements(By.CSS_SELECTOR, "li[role='option']")
                        if options:
                            self.driver.execute_script("arguments[0].click();", options[0])
                            return True
                    except (NoSuchElementException, StaleElementReferenceException):
                        pass
                    
                    return False
                except Exception:
                    return False
            
            elif element_type == 'multiselects':
                # Similar to selects, but can select multiple options
                try:
                    self.driver.execute_script("arguments[0].click();", element)
                    
                    # Wait for the dropdown to open
                    time.sleep(1)
                    
                    # Find and click the first option
                    try:
                        options = self.driver.find_elements(By.CSS_SELECTOR, "li[role='option']")
                        if options and len(options) > 0:
                            self.driver.execute_script("arguments[0].click();", options[0])
                            return True
                    except (NoSuchElementException, StaleElementReferenceException):
                        pass
                    
                    return False
                except Exception:
                    return False
            
            elif element_type == 'sliders':
                # Find the slider handle and move it
                try:
                    slider_handle = element.find_element(By.CSS_SELECTOR, "[role='slider']")
                    self.driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", slider_handle)
                    
                    # Move the slider to a different position
                    current_value = int(slider_handle.get_attribute("aria-valuenow"))
                    min_value = int(slider_handle.get_attribute("aria-valuemin"))
                    max_value = int(slider_handle.get_attribute("aria-valuemax"))
                    
                    # Calculate a new value
                    new_value = min_value + (max_value - min_value) // 2
                    if new_value == current_value:
                        new_value = max_value if current_value != max_value else min_value
                    
                    # Set the new value using JavaScript
                    self.driver.execute_script(
                        f"arguments[0].setAttribute('aria-valuenow', '{new_value}');"
                        f"arguments[0].dispatchEvent(new Event('change', {{bubbles: true}}));",
                        slider_handle
                    )
                    
                    return True
                except (NoSuchElementException, StaleElementReferenceException):
                    pass
                
                return False
            
            elif element_type == 'number_inputs':
                # Find the input field and enter a value
                try:
                    input_field = element.find_element(By.CSS_SELECTOR, "input[type='number']")
                    self.driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", input_field)
                    
                    # Clear the field and enter a new value using JavaScript
                    self.driver.execute_script(
                        "arguments[0].value = '42';"
                        "arguments[0].dispatchEvent(new Event('change', {bubbles: true}));",
                        input_field
                    )
                    
                    return True
                except (NoSuchElementException, StaleElementReferenceException):
                    pass
                
                return False
            
            elif element_type == 'text_inputs':
                # Find the input field and enter text
                try:
                    input_field = element.find_element(By.CSS_SELECTOR, "input[type='text']")
                    self.driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", input_field)
                    
                    # Clear the field and enter text using JavaScript
                    self.driver.execute_script(
                        "arguments[0].value = 'Test input';"
                        "arguments[0].dispatchEvent(new Event('change', {bubbles: true}));",
                        input_field
                    )
                    
                    return True
                except (NoSuchElementException, StaleElementReferenceException):
                    pass
                
                return False
            
            elif element_type == 'date_inputs':
                # Find the input field and enter a date
                try:
                    input_field = element.find_element(By.CSS_SELECTOR, "input[type='date']")
                    self.driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", input_field)
                    
                    # Set a date using JavaScript
                    self.driver.execute_script(
                        "arguments[0].value = '2023-01-01';"
                        "arguments[0].dispatchEvent(new Event('change', {bubbles: true}));",
                        input_field
                    )
                    
                    return True
                except (NoSuchElementException, StaleElementReferenceException):
                    pass
                
                return False
            
            elif element_type == 'tabs':
                # Try JavaScript click first
                try:
                    self.driver.execute_script("arguments[0].click();", element)
                    
                    # Wait for the tab content to load
                    time.sleep(1)
                    
                    return True
                except Exception:
                    # If JavaScript click fails, try regular click
                    try:
                        element.click()
                        time.sleep(1)
                        return True
                    except Exception:
                        return False
            
            elif element_type == 'expanders':
                # Find the expander header and click it
                try:
                    header = element.find_element(By.CSS_SELECTOR, "[data-testid='stExpander'] > div:first-child")
                    self.driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", header)
                    
                    # Try JavaScript click first
                    try:
                        self.driver.execute_script("arguments[0].click();", header)
                        return True
                    except Exception:
                        # If JavaScript click fails, try regular click
                        try:
                            header.click()
                            return True
                        except Exception:
                            return False
                except (NoSuchElementException, StaleElementReferenceException):
                    pass
                
                return False
            
            elif element_type == 'links':
                # Get the href attribute
                href = element.get_attribute("href")
                
                # Only click links that point to the same domain or are anchors
                if href and (href.startswith("#") or self.driver.current_url.split("/")[2] in href):
                    # Try JavaScript click first
                    try:
                        self.driver.execute_script("arguments[0].click();", element)
                        return True
                    except Exception:
                        # If JavaScript click fails, try regular click
                        try:
                            element.click()
                            return True
                        except Exception:
                            return False
                
                return False
            
            return False
        
        except Exception as e:
            print(f"Error interacting with {element_type}: {e}")
            return False 