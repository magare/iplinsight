#!/usr/bin/env python3
"""
End-to-End Test Runner for Streamlit App

This script runs end-to-end tests on a Streamlit app using Selenium for browser automation.
It systematically clicks through all buttons, selects options from dropdowns, and fills in forms,
capturing screenshots and console logs during traversal, and detecting any errors or exceptions.

Usage:
    python run_e2e_tests.py [--port PORT] [--headless] [--app-path APP_PATH] [--max-elements MAX_ELEMENTS] [--wait-time WAIT_TIME]

Options:
    --port PORT         Port to run the Streamlit app on (default: random free port)
    --headless          Run the browser in headless mode (default: True)
    --app-path APP_PATH Path to the Streamlit app file (default: app/app.py)
    --max-elements MAX_ELEMENTS Maximum number of elements to test (default: 10)
    --wait-time WAIT_TIME Wait time in seconds for elements to appear (default: 5)
    --no-headless       Run the browser in visible mode (not headless)
"""

import os
import sys
import argparse
from pathlib import Path

# Add the parent directory to the path so we can import the app modules
sys.path.insert(0, str(Path(__file__).parents[2]))

from app.tests.e2e.test_runner import StreamlitTestRunner


def parse_args():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description="Run end-to-end tests on a Streamlit app")
    parser.add_argument("--port", type=int, help="Port to run the Streamlit app on")
    parser.add_argument("--headless", action="store_true", default=True, help="Run the browser in headless mode")
    parser.add_argument("--app-path", type=str, help="Path to the Streamlit app file")
    parser.add_argument("--max-elements", type=int, default=10, help="Maximum number of elements to test")
    parser.add_argument("--wait-time", type=int, default=5, help="Wait time in seconds for elements to appear")
    parser.add_argument("--no-headless", action="store_true", help="Run the browser in visible mode (not headless)")
    
    args = parser.parse_args()
    
    # Override headless if no-headless is specified
    if args.no_headless:
        args.headless = False
    
    return args


def main():
    """Run the tests."""
    args = parse_args()
    
    # Set default app path if not provided
    app_path = args.app_path
    if not app_path:
        app_path = Path(__file__).parents[1] / "app.py"
        if not app_path.exists():
            print(f"Default app path {app_path} does not exist")
            return 1
    
    # Create the test runner
    runner = StreamlitTestRunner(
        app_path=app_path,
        port=args.port,
        headless=args.headless,
        max_elements=args.max_elements,
        wait_time=args.wait_time
    )
    
    # Run the tests
    report_path = runner.run_tests()
    
    if report_path:
        print(f"Test report generated at {report_path}")
        return 0
    else:
        print("Failed to generate test report")
        return 1


if __name__ == "__main__":
    sys.exit(main()) 