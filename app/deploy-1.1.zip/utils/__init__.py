"""
IPL Data Mining app utilities
"""
