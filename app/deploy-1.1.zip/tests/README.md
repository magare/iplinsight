# Streamlit App Testing Framework

This testing framework provides end-to-end testing for Streamlit applications. It launches the actual Streamlit app in a separate process and uses Selenium for browser automation to interact with the UI.

## Features

- Launches the Streamlit app in a separate process
- Uses Selenium for browser automation
- Systematically clicks through all buttons, selects options from dropdowns, and fills in forms
- Captures screenshots and console logs during traversal
- Detects any errors, exceptions, or visual anomalies
- Generates comprehensive HTML and JSON reports

## Directory Structure

```
app/tests/
├── e2e/                  # End-to-end testing framework
│   ├── app_launcher.py   # Launches the Streamlit app in a separate process
│   ├── webdriver_manager.py # Manages the Selenium WebDriver
│   ├── element_detector.py # Detects and interacts with UI elements
│   ├── error_detector.py # Detects errors and exceptions
│   ├── test_reporter.py  # Generates test reports
│   └── test_runner.py    # Orchestrates the testing process
├── screenshots/          # Screenshots captured during testing
├── reports/              # Test reports
├── requirements-test.txt # Testing dependencies
├── run_e2e_tests.py      # Main script to run the tests
└── README.md             # This file
```

## Installation

1. Install the required dependencies:

```bash
pip install -r app/tests/requirements-test.txt
```

2. Make sure you have Chrome installed, as the framework uses Chrome for browser automation.

## Usage

Run the tests using the `run_e2e_tests.py` script:

```bash
python app/tests/run_e2e_tests.py
```

### Command-line Options

- `--port PORT`: Port to run the Streamlit app on (default: random free port)
- `--headless`: Run the browser in headless mode (default: True)
- `--no-headless`: Run the browser in visible mode (not headless)
- `--app-path APP_PATH`: Path to the Streamlit app file (default: app/app.py)
- `--max-elements MAX_ELEMENTS`: Maximum number of elements to test (default: 10)
- `--wait-time WAIT_TIME`: Wait time in seconds for elements to appear (default: 5)

Example:

```bash
# Run tests with visible browser and test more elements
python app/tests/run_e2e_tests.py --no-headless --max-elements 20

# Run tests with a longer wait time for slow connections
python app/tests/run_e2e_tests.py --wait-time 10

# Run tests on a specific port with a custom app path
python app/tests/run_e2e_tests.py --port 8501 --app-path app/custom_app.py
```

## Test Reports

After running the tests, the framework generates both HTML and JSON reports in the `app/tests/reports/` directory. The HTML report provides a user-friendly view of the test results, including:

- Summary of test results (passed, failed, warnings)
- Details of each test case
- Screenshots captured during testing
- Error messages and console logs

## Screenshots

Screenshots are saved in the `app/tests/screenshots/` directory. Each screenshot is named with a timestamp and the name of the test case.

## How It Works

1. The framework launches the Streamlit app in a separate process.
2. It then uses Selenium to navigate to the app and interact with the UI.
3. It systematically finds and interacts with all interactive elements (buttons, dropdowns, etc.).
4. For each interaction, it captures screenshots before and after, and checks for errors.
5. It generates a comprehensive report of the test results.

## Customization

You can customize the testing framework by modifying the following files:

- `app_launcher.py`: Customize how the Streamlit app is launched.
- `element_detector.py`: Add support for additional UI elements or customize interaction behavior.
- `error_detector.py`: Customize error detection logic.
- `test_reporter.py`: Customize the format of test reports.
- `test_runner.py`: Customize the testing strategy.

## Troubleshooting

- **WebDriver Issues**: If you encounter issues with the WebDriver, make sure you have Chrome installed and that the ChromeDriver version is compatible with your Chrome version.
- **Port Conflicts**: If you encounter port conflicts, try specifying a different port using the `--port` option.
- **Streamlit App Not Starting**: Check the console output for any errors related to starting the Streamlit app.
- **Element Interaction Issues**: If elements are not being interacted with correctly, try increasing the wait time using the `--wait-time` option.
- **Test Coverage**: If you want to test more elements, increase the `--max-elements` value.

## Contributing

Contributions to improve the testing framework are welcome! Please feel free to submit pull requests or open issues for any bugs or feature requests.
