"""
Testing Framework for Streamlit Apps

This package provides testing utilities for Streamlit applications.
"""

__version__ = "1.0.0" 